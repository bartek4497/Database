-- ==========================
--    SCHEMAT SKRYPTU
-- =========================

-- -------------------------
-- Tworzenie bazy danych
-- Zakomentuj ten fragment, jeśli uruchamiasz skrypt na serwerze MSSQL.
-- -------------------------
USE master
GO

IF DB_ID('Wypozyczalnia_sprzetu_zimowego') IS NULL
CREATE DATABASE Wypozyczalnia_sprzetu_zimowego
GO

USE Wypozyczalnia_sprzetu_zimowego

-- ------------------------------------------------------
-- Usuwanie tabel (w odwrotnej kolejności do tworzenia!)
-- ------------------------------------------------------

IF OBJECT_ID('wypozyczenia','U') IS NOT NULL
DROP TABLE wypozyczenia

IF OBJECT_ID('pracownicy','U') IS NOT NULL
DROP TABLE pracownicy

IF OBJECT_ID('klienci','U') IS NOT NULL
DROP TABLE klienci

IF OBJECT_ID('sprzet','U') IS NOT NULL
DROP TABLE sprzet

IF OBJECT_ID('cennik','U') IS NOT NULL
DROP TABLE cennik

IF OBJECT_ID('rodzaj_sprzetu','U') IS NOT NULL
DROP TABLE rodzaj_sprzetu



GO

-- --------------------------------
-- Tworzenie tabel
-- --------------------------------


IF OBJECT_ID('rodzaj_sprzetu','U') IS NULL
CREATE TABLE rodzaj_sprzetu(
	rodzaj_ID int IDENTITY(1,1) NOT NULL,
	rodzaj nvarchar(50) NOT NULL,
	symbol_sprzetu nvarchar(5) NOT NULL,
 CONSTRAINT PK_rodzaje_urlopow PRIMARY KEY(symbol_sprzetu ASC)
)

IF OBJECT_ID('sprzet','U') IS NULL
CREATE TABLE sprzet
(
	sprzet_ID int IDENTITY(1,1) NOT NULL,
	nazwa nvarchar(100) NOT NULL,
	symbol nvarchar(5) NOT NULL,
	wartosc int NOT NULL,         
 CONSTRAINT PK_sprzet PRIMARY KEY (sprzet_ID ASC)
)

IF OBJECT_ID('cennik','U') IS NULL
CREATE TABLE cennik
(
	cennik_ID int IDENTITY(1,1) NOT NULL,
	sprzet nvarchar(5) NOT NULL,
	cena int NOT NULL, 				
	cena_ulga int NOT NULL, 				
	data_aktualizacji date NOT NULL,
	uwagi nvarchar(50) NULL,
 CONSTRAINT PK_cennik PRIMARY KEY(cennik_ID ASC)
)

IF OBJECT_ID('klienci','U') IS NULL
CREATE TABLE klienci
(
	klienci_ID int IDENTITY(1,1) NOT NULL,
	imie nvarchar(20) NOT NULL,
	nazwisko nvarchar(30) NOT NULL,
	miasto nvarchar(20) NULL,
	data_dodania date NOT NULL,
 CONSTRAINT PK_klienci PRIMARY KEY(klienci_ID ASC)
) 

IF OBJECT_ID('pracownicy','U') IS NULL
CREATE TABLE pracownicy
(
	pracownicy_ID int IDENTITY(1,1) NOT NULL,
	imie nvarchar(20) NOT NULL,
	nazwisko nvarchar(30) NOT NULL,
	miasto nvarchar(20) NULL,
	data_zatr date NOT NULL,
	login nvarchar(10) NOT NULL,
 CONSTRAINT PK_pracownicy PRIMARY KEY(pracownicy_ID ASC)
)

IF OBJECT_ID('wypozyczenia','U') IS NULL
CREATE TABLE wypozyczenia
(
	wypozyczenia_ID int IDENTITY(1,1) NOT NULL,
	data datetime NOT NULL,
	klient int NOT NULL,
	sprzet int NOT NULL,
	pracownik int NOT NULL,
	jak_dlugo int NOT NULL,
	czy_ulga bit NOT NULL,
	uwagi nvarchar(50) NULL,
 CONSTRAINT wypozyczenia_ID PRIMARY KEY(wypozyczenia_ID ASC) 
)

GO

-- --------------------------------
-- Klucze obce indexy
-- --------------------------------
ALTER TABLE wypozyczenia ADD  CONSTRAINT DF_data  DEFAULT (getdate()) FOR data

ALTER TABLE wypozyczenia ADD  CONSTRAINT DF_czy_ulga  DEFAULT ((0)) FOR czy_ulga

ALTER TABLE wypozyczenia  WITH CHECK ADD  CONSTRAINT FK_wypozyczenia_pracownicy FOREIGN KEY(pracownik)
REFERENCES pracownicy (pracownicy_ID)
ALTER TABLE wypozyczenia CHECK CONSTRAINT FK_wypozyczenia_pracownicy

ALTER TABLE wypozyczenia  WITH CHECK ADD  CONSTRAINT FK_wypozyczenia_klienci FOREIGN KEY(klient)
REFERENCES klienci (klienci_ID)
ALTER TABLE wypozyczenia CHECK CONSTRAINT FK_wypozyczenia_klienci

ALTER TABLE wypozyczenia  WITH CHECK ADD  CONSTRAINT FK_wypozyczenia_sprzet FOREIGN KEY(sprzet)
REFERENCES sprzet (sprzet_ID)
ALTER TABLE wypozyczenia CHECK CONSTRAINT FK_wypozyczenia_sprzet

ALTER TABLE sprzet  WITH CHECK ADD  CONSTRAINT FK_symbol_sprzetu FOREIGN KEY(symbol)
REFERENCES rodzaj_sprzetu (symbol_sprzetu)
ALTER TABLE sprzet CHECK CONSTRAINT FK_symbol_sprzetu

ALTER TABLE cennik  WITH CHECK ADD  CONSTRAINT FK_cennik FOREIGN KEY(sprzet)
REFERENCES rodzaj_sprzetu (symbol_sprzetu)
ALTER TABLE cennik CHECK CONSTRAINT FK_cennik

CREATE UNIQUE NONCLUSTERED INDEX rodzaj1 ON rodzaj_sprzetu(rodzaj ASC)


GO

-- ---------------------------------
-- Wstawianie wartości do tabel
-- ---------------------------------

INSERT INTO rodzaj_sprzetu
	(rodzaj,symbol_sprzetu)
VALUES
    ('Narty','N')
   ,('Kaski','K')
   ,('Buty narciarskie','B')
   ,('Deski snowbordowe','DS')
   ,('Gogle','G')
   ,('Odziez narciarska','ON')
   ,('Akcesoria','A')
GO

INSERT INTO sprzet
           (nazwa,symbol,wartosc)
     VALUES
           ('Narty zjazdowe NORDICA SPITFIRE DOBERMAN','N',350)
          ,('Narty zjazdowe ATOMIC NOMAD','N',170)
          ,('Narty zjazdowe dla dzieci HEAD SUPERSHAPE TEAM','N',400)
          ,('Narty ROSSIGNOL ZEST RADICAL GS PRO','N',400)
          ,('Kask SALOMON BRIDGE AUDIO','K',307)
          ,('Kask SALOMON QUEST','K',649)
          ,('Buty ROSSIGNOL COMP J3','B',280)
          ,('Buty HEAD NEXT EDGE 85','B',499)
          ,('Buty dla dzieci SALOMON T1 174','B',99)
          ,('Deska SALOMON ASSASSIN','DS',1540)
          ,('Deska SALOMON LOTUS','DS',900)
          ,('SALOMON XVIEW BLUE GOGLE','G',350)
          ,('SALOMON XVIEW WHITE','G',245)
          ,('SALOMON XVIEW WHITE','G',300)
          ,('Kurtka dla dzieci SOFTSHELL','ON',110)
          ,('spodnie narciarskie dla dzieci','ON',60)
          ,('Ochroniacze narciarskie','A',100)
          ,('Zestaw uchwytów do  kamery ','A',70)
          
GO

INSERT INTO cennik
           (sprzet,cena,cena_ulga,data_aktualizacji)
     VALUES
        ('N',25,15,'2018-01-01') 
		,('K',20,10,'2018-01-01') 
		,('B',45,25,'2018-01-01')
		,('DS',26,15,'2018-01-01')   
		,('G',15,10,'2018-01-01')  
		,('ON',10,5,'2018-01-01')  
		,('A',15,8,'2018-01-01')   
GO

INSERT INTO pracownicy
           (imie,nazwisko,miasto,data_zatr,login)
     VALUES                                                  
		 ('Adam','Adamski','Karpacz','2016-01-01','iadnad1')	                                                  
		,('Marcin','Marcinkowski','Szklarska Porebęba','2015-01-01','imanma1')	                                                  
		,('Jan','Jankowski','Szklarska Porebęba','2015-12-01','ijanja1')	                                                                                                    

GO

INSERT INTO klienci
           (imie,nazwisko,miasto,data_dodania)
     VALUES                                                  
		 ('Arkadiusz','Kowalski','Warszawa','2016-01-01')	                                                  
		,('Sefan','Michułka','Wrocław','2015-01-01')	                                                  
		,('Janina','Stępień','Poznań','2015-12-01')	                                                                                                    
		,('Teodor','Staroń','Szczecin','2015-12-01')	                                                                                                    
		,('Jan','Marszał','Kielce','2015-12-01')	                                                                                                    

GO

INSERT INTO wypozyczenia
           (data,klient,sprzet,pracownik,jak_dlugo,czy_ulga)
     VALUES
           ('2015-12-01 07:36',1,1,2,2,0)
		  ,('2015-12-02 08:36',2,2,2,1,0)
		  ,('2018-01-02 08:59',1,3,1,1,1)
		  ,('2018-02-02 08:18',3,2,3,1,0)
		  ,('2018-02-02 08:36',4,5,1,1,0)
		   
GO
-- ---------------------------------
-- Usuwanie i tworzenie widoków
-- ---------------------------------

IF OBJECT_ID('klienci_z_najwiekszym_stazem','V') IS NOT NULL
DROP VIEW klienci_z_najwiekszym_stazem
GO

CREATE VIEW klienci_z_najwiekszym_stazem
AS
SELECT TOP 3 imie, klienci_ID, nazwisko, ROUND(DATEDIFF(mm, data_dodania, GETDATE()) / 12.0, 1) AS Staz
FROM            dbo.klienci
ORDER BY Staz DESC
GO

IF OBJECT_ID('zestawienie','V') IS NOT NULL
DROP VIEW zestawienie
GO

CREATE VIEW zestawienie
AS
SELECT wypozyczenia.data, klienci.imie, klienci.nazwisko, sprzet.nazwa,sprzet.symbol , 
wypozyczenia.jak_dlugo,wypozyczenia.czy_ulga,
cennik.cena, cennik.cena_ulga,pracownicy.login,
IIf(wypozyczenia.czy_ulga = 1, wypozyczenia.jak_dlugo * cennik.cena_ulga, wypozyczenia.jak_dlugo * cennik.cena) AS do_zaplaty
FROM cennik INNER JOIN
rodzaj_sprzetu ON cennik.sprzet = rodzaj_sprzetu.symbol_sprzetu INNER JOIN
sprzet ON rodzaj_sprzetu.symbol_sprzetu = sprzet.symbol INNER JOIN
wypozyczenia ON sprzet.sprzet_ID = wypozyczenia.sprzet INNER JOIN
klienci ON wypozyczenia.klient = klienci.klienci_ID INNER JOIN
pracownicy ON wypozyczenia.pracownik = pracownicy.pracownicy_ID
GO


IF OBJECT_ID('najwiekszy_przychod_dni','V') IS NOT NULL
DROP VIEW najwiekszy_przychod_dni
GO

CREATE VIEW najwiekszy_przychod_dni
AS
SELECT TOP 10 DATEFROMPARTS(YEAR(data),MONTH(data),DAY(data)) as dzien, SUM(do_zaplaty) AS dzienny_przychod
FROM zestawienie
GROUP BY data
ORDER BY dzienny_przychod DESC
GO


IF OBJECT_ID('przychod_miesieczny','V') IS NOT NULL
DROP VIEW przychod_miesieczny
GO

CREATE VIEW przychod_miesieczny
AS
SELECT YEAR(data) AS rok,MONTH(data)as miesiac, SUM(do_zaplaty) AS przychod
FROM zestawienie
GROUP BY YEAR(data),MONTH(data)
GO


IF OBJECT_ID('najczesciej_wypozyczany','V') IS NOT NULL
DROP VIEW najczesciej_wypozyczany
GO

CREATE VIEW najczesciej_wypozyczany
AS
SELECT TOP (5) nazwa, SUM(jak_dlugo) AS suma_godzin
FROM            dbo.zestawienie
GROUP BY nazwa
ORDER BY suma_godzin DESC
GO


IF OBJECT_ID('sprzet_w_wypozyczeniu','V') IS NOT NULL
DROP VIEW sprzet_w_wypozyczeniu
GO

CREATE VIEW sprzet_w_wypozyczeniu
AS
SELECT sprzet.sprzet_ID, sprzet.nazwa, sprzet.symbol, sprzet.wartosc
FROM  wypozyczenia INNER JOIN
    sprzet ON wypozyczenia.sprzet = sprzet.sprzet_ID
WHERE (DATEADD(HOUR, wypozyczenia.jak_dlugo, wypozyczenia.data) > GETDATE())
GO

-- ---------------------------------
-- Tworzenie procedur
-- ---------------------------------
IF OBJECT_ID('wielkosc_sprzedarzy_wg_sprzetu_w_danym_roku','P') IS NOT NULL
DROP PROCEDURE wielkosc_sprzedarzy_wg_sprzetu_w_danym_roku
GO


CREATE PROCEDURE [dbo].[wielkosc_sprzedarzy_wg_sprzetu_w_danym_roku]
    @p1 int,
	@p2 char(2)

AS
BEGIN
    SET NOCOUNT ON;
SELECT YEAR(data) AS rok, nazwa, symbol, SUM(do_zaplaty) AS razem
FROM  zestawienie 
GROUP BY nazwa, symbol, YEAR(data)
HAVING (YEAR(data) = @p1) AND (symbol = @p2) 
END
GO


IF OBJECT_ID('niedochodowy_sprzet','P') IS NOT NULL
DROP PROCEDURE niedochodowy_sprzet
GO

CREATE PROCEDURE niedochodowy_sprzet
    @p1 char
AS
BEGIN
    SET NOCOUNT ON;
SELECT top 1 nazwa,symbol, SUM(do_zaplaty) AS przychod
FROM zestawienie
GROUP BY nazwa,symbol
Having symbol=@p1
Order by 3
END
GO


-- ---------------------------------------------
-- Utworzenie raportów (wywołanie widoków)
-- ---------------------------------------------

-- Wykorzystanie urlopów
PRINT('Zestawienie główne')
SELECT * FROM zestawienie

-- Dni z największym przychodem
PRINT('Dni z największym przychodem')
SELECT * FROM najwiekszy_przychod_dni

-- Najczesciej_wypozyczany sprzęt
PRINT('Najczesciej_wypozyczany sprzęt')
SELECT * FROM najczesciej_wypozyczany

-- Sprzęt aktualnie wypożyczony
PRINT('Sprzęt aktualnie wypożyczony')
SELECT * FROM sprzet_w_wypozyczeniu

-- Wielkosc sprzedarzy wg sprzetu w danym roku
PRINT('Wielkosc sprzedarzy wg sprzetu w danym roku')
EXEC wielkosc_sprzedarzy_wg_sprzetu_w_danym_roku 2015, 'N'

-- Najmniej dochodowy sprzęt w grupach
PRINT('Najmniej dochodowy sprzęt w grupach')
EXEC niedochodowy_sprzet 'N'

-- Klienci z najwiekszym stazem
PRINT('Klienci z najwiekszym stazem')
SELECT * FROM klienci_z_najwiekszym_stazem

-- ---------------------------------------------
-- Usunięcie bazy
-- ---------------------------------------------

USE master
GO

IF DB_ID('Wypozyczalnia_sprzetu_zimowego') IS NOT NULL
DROP DATABASE Wypozyczalnia_sprzetu_zimowego
GO
